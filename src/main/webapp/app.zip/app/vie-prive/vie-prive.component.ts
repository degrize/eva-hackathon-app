import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jhi-vie-prive',
  templateUrl: './vie-prive.component.html',
  styleUrls: ['./vie-prive.component.scss'],
})
export class ViePriveComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
