import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jhi-annonce',
  templateUrl: './annonce.component.html',
  styleUrls: ['./annonce.component.scss'],
})
export class AnnonceComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
