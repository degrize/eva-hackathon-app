export enum Devise {
  EURO = 'EURO',

  CEDI = 'CEDI',

  DLASI = 'DLASI',

  DOLLAR = 'DOLLAR',

  FCFA = 'FCFA',

  LIVRE = 'LIVRE',

  LEONE = 'LEONE',

  NAIRA = 'NAIRA',

  YEN = 'YEN',
}
