export enum EtatCompte {
  PREMIUM = 'PREMIUM',

  NORMAL = 'NORMAL',
}
