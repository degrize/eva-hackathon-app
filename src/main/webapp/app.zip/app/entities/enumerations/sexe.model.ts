export enum Sexe {
  F = 'F',

  M = 'M',

  JE_PREFERE_NE_PAS_LE_DIRE = 'JE_PREFERE_NE_PAS_LE_DIRE',
}
