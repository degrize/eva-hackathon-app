import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jhi-regle-condition',
  templateUrl: './regle-condition.component.html',
  styleUrls: ['./regle-condition.component.scss'],
})
export class RegleConditionComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
