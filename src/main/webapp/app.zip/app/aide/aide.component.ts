import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jhi-aide',
  templateUrl: './aide.component.html',
  styleUrls: ['./aide.component.scss'],
})
export class AideComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
