import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jhi-remboursement',
  templateUrl: './remboursement.component.html',
  styleUrls: ['./remboursement.component.scss'],
})
export class RemboursementComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
